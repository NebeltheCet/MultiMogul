﻿using System;

namespace $rootnamespace$;

// an example class for implementing packets
public class $safeitemname$ : RawPacket {
	private const PacketType customType = PacketType.$safeitemname$;

	public $safeitemname$() : base(customType, nameof($safeitemname$)) {}

	// packet members
	//public int exampleInt = 0;

	// packet type handler register
	static $safeitemname$() {
		RegisterHandler<$safeitemname$>((p, v) => {
			var q = ($safeitemname$)v;

			//p.Write(q.exampleInt);

		}, p => new $safeitemname$ {
			//exampleInt = p.Read<int>()
		});
	}

	// packet conversion serializer
	public override RawPacket ToRawPacket() {
		var packet = new RawPacket(customType, nameof($safeitemname$));
		packet.Write<$safeitemname$>(this);

		return packet;
	}
}
