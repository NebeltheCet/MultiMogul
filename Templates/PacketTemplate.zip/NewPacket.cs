﻿using System;

namespace $rootnamespace$;

// an example class for implementing packets
public class $safeitemname$ : RawPacket {
	private const PacketType customType = PacketType.Invalid;

public $safeitemname$() : base(customType, "$safeitemname$") {
		if (this.Usage == PacketUsage.Writing) {
	this.Write <$safeitemname$> (this);
}
}

// packet members
//public int exampleInt = 0;

// packet type handler register
static $safeitemname$() {
		RegisterHandler<$safeitemname$>((p, v) => {
			var q = ($safeitemname$)v;

			//p.Write(q.exampleInt);

		}, p => new $safeitemname$ {
			//exampleInt = p.Read<int>()
		});
	}
}
