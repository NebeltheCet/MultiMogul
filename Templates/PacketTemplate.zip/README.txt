this template was made to remove the repetition between creating new packet types for our MineMogul mod, MultiMogul.

to use this template you have to move the zip file into
Documents/Visual Studio <Version>/Templates/ItemTemplates/C#/